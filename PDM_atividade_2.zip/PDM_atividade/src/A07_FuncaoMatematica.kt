import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt
import kotlin.math.*

// aula 07 funções matemáticas

fun main(){
    println(max(5,10));
    println(min(5,10));
    println(sqrt(49f));

    println(PI);
    println(E);

    println(round(456212.9865468765487655555));
    //arredondar numero
    println(round(PI));
    println(round(E));

    val PI = 3.14159;
    print(PI);

}