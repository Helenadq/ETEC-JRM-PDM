/*
Aula 04: Variaveis, tipo de dados e operadores aritméticos


a. Crie um novo arquivo chamado A04_Exercicio.kt com uma função main

b. Declare uma variavel mutavel capaz de armazenar seu nome completo

c. Declare uma variavel de texto sem valor algum

d. Declare uma variavel imutavel com o menor tipo de dado possível capaz de armazenar o numero que vc calça

e. Declare uma variavel capaz de armazenar o PIB do Brasil este em 2024 (cerca de 10.900.000.000.000,00)

f. Declare uma variavel capaz de armazenar a população do Brasil (cerca de 212,600.000)

g. Imprima no terminal o valor do PIB per capita (PIB / população)

h. Rode seu programa de forma que não possua erros de compilação ou execução

 */

//ATIVIDADE a
fun main() {

//ATIVIDADE b
    var nomeCompleto: String = "Helena Delmédico de Queiroz";

//ATIVIDADE c
    var variavelnull = null;

//ATIVIDADE d
    val numeroCalcado: Byte = 36;

//ATIVIDADE e
    var pibBrasil: Double = 10_900_000_000_000.00;

//ATIVIDADE f
    var populacaoBrasil: Int = 212_600_000;

//ATIVIDADE g
    var resultado: Double;
    resultado = pibBrasil / populacaoBrasil;
    println("Resultado PIB per capita: ${resultado}");

//ATIVIDADE h
    //Deu tudo certo, no println apareceu "Resultado PIB per capita: 51269.990592662274"

}